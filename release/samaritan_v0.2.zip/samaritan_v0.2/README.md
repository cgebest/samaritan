# Samaritan

Highlight conflict-of-interest reviewers on Microsoft CMT.

This is the code repo for the chrome extension of same name.

## License

[GNU Affero General Public License v3](LICENSE).

## Questions?

Issues and pull requests are welcome.

For any questions or comments, please reach out to Chang Ge.
